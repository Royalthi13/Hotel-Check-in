// ─── Barrel export de src/index.ts ───────────────────────────────────────────
//
// REGLA: solo exportar lo que un consumidor EXTERNO necesita conocer.
//

// Tipos públicos
export type {
  AppMode,
  StepId,
  Reserva,
  GuestData,
  PartialGuestData,
  CheckinState,
  FormErrors,
  NavDirection,
  CheckinNav,
  CheckinActions,
} from "./types";

// Hook
export { useCheckin } from "./hooks/useCheckin";

// Validación — solo las funciones que realmente existen
export {
  useFormValidation,
  validatePersonal,
  validateContacto,
} from "./hooks/useFormValidation";

// Constantes públicas
export {
  PAISES,
  NACIONALIDADES,
  TIPOS_DOCUMENTO,
  HORAS_LLEGADA,
SEXOS,
  DOT_STEPS_BASE,
} from "./constants";

// Componentes UI
export * from "./components/ui";

// Layout
export { AppShell } from "./layout/AppShell";

// Screens
export { ScreenTabletBuscar } from "./screens/ScreenTabletBuscar";
export { ScreenBienvenida } from "./screens/ScreenBienvenida";
export { ScreenEscanear } from "./screens/ScreenEscanear";
export { ScreenConfirmarDatos } from "./screens/ScreenConfirmardatos";
export { ScreenFormPersonal, ScreenFormContacto } from "./screens/ScreenForms";
export {
  ScreenFormExtras,
  ScreenRevision,
  ScreenExito,
} from "./screens/ScreenExtrasRevisionExito";
